package com.movie.reviews.domain;

public enum Role {

	USER, ADMIN;

}
