insert into genres values(1, 'Action');
insert into genres values(2, 'Drama');
insert into genres values(3, 'Romance');
insert into genres values(4, 'Science Fiction');
insert into genres values(5, 'Horror');
insert into genres values(6, 'Comedy');
insert into genres values(7, 'Thriller');
insert into genres values(8, 'Sports');

insert into languages values(1, 'Tamil');
insert into languages values(2, 'English');
insert into languages values(3, 'Hindi');
insert into languages values(4, 'Malayalam');
insert into languages values(5, 'Telugu');
insert into languages values(6, 'Kanada');
insert into languages values(7, 'Chinese');
insert into languages values(8, 'Korean');

