import React, { Component } from "react";

class HomePage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return <h1>Welcome to Movie Review Portal</h1>;
  }
}

export default HomePage;
